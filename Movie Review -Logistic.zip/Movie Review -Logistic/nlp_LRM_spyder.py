# -*- coding: utf-8 -*-
"""
Created on Tue Jun  8 02:48:38 2021

@author: mpavithr
"""

import pandas as pd
import numpy as np
import string
import re
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer

data = [line.rstrip() for line in open('train.txt')]
print(len(data))
#print(data)

data1=[]
for i in data:
    label=i.split(" ",1)
    data1.append(label)
    
#print(data1)


messages=pd.DataFrame(data1,columns=['label','message'])
print(messages)

#Performing Stemming 
ps = PorterStemmer()
corpus = []
for i in range(0, len(messages)):
    review = re.sub('[^a-zA-Z]', ' ', messages['message'][i])
    review = review.lower()
    review = review.split()
    
    review = [ps.stem(word) for word in review if not word in stopwords.words('english')]
    review = ' '.join(review)
    corpus.append(review)
    
    
from sklearn.feature_extraction.text import CountVectorizer
cv = CountVectorizer()
X = cv.fit_transform(corpus).toarray()

y=messages['label']

print(y)
print(X)


# Train Test Split

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.30, random_state = 100)



from sklearn.linear_model import LogisticRegression
nlp_logmodel = LogisticRegression()
nlp_logmodel.fit(X_train,y_train)


y_pred=nlp_logmodel.predict(X_test)
y_pred


from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score
print (classification_report(y_test, y_pred))

print("Accuracy score: ",accuracy_score(y_test, y_pred))


#Evaluating the model with dev.txt

dev_data = [line.rstrip() for line in open('dev.txt')]
print(len(dev_data))
